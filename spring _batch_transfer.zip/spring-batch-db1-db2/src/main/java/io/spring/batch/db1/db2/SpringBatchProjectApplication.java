package io.spring.batch.db1.db2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchProjectApplication.class, args);
	}

}
